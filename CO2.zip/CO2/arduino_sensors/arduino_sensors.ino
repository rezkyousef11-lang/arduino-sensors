#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT11

#define GAS_SENSOR_PIN A0
#define CO2_SENSOR_PIN A1

#define LED_TEMP 3
#define LED_GAS 4
#define LED_CO2 5

#define TEMP_THRESHOLD 30.0
#define GAS_THRESHOLD 400
#define CO2_THRESHOLD 1000

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  dht.begin();

  pinMode(LED_TEMP, OUTPUT);
  pinMode(LED_GAS, OUTPUT);
  pinMode(LED_CO2, OUTPUT);

  digitalWrite(LED_TEMP, LOW);
  digitalWrite(LED_GAS, LOW);
  digitalWrite(LED_CO2, LOW);
}

void loop() {
  float temperature = dht.readTemperature();
  int gasValue = analogRead(GAS_SENSOR_PIN);
  int potValue = analogRead(CO2_SENSOR_PIN);

  int co2Value = map(potValue, 0, 1023, 400, 2000);

  if (isnan(temperature)) {
    temperature = 0;
  }

  digitalWrite(LED_TEMP, (temperature > TEMP_THRESHOLD) ? HIGH : LOW);
  digitalWrite(LED_GAS, (gasValue > GAS_THRESHOLD) ? HIGH : LOW);
  digitalWrite(LED_CO2, (co2Value > CO2_THRESHOLD) ? HIGH : LOW);

  Serial.print(temperature);
  Serial.print(",");
  Serial.print(gasValue);
  Serial.print(",");
  Serial.println(co2Value);

  delay(1000);
}
