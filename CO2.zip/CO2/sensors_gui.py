import serial
import serial.tools.list_ports
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import deque
from datetime import datetime
import time

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

MAX_POINTS = 50

class SensorMonitorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Monitoraggio Sensori")
        self.root.geometry("1400x800")

        self.ser = None
        self.running = False

        self.temp_data = deque(maxlen=MAX_POINTS)
        self.gas_data = deque(maxlen=MAX_POINTS)
        self.co2_data = deque(maxlen=MAX_POINTS)
        self.timestamps = deque(maxlen=MAX_POINTS)

        self.current_temp = 0
        self.current_gas = 0
        self.current_co2 = 0

        self.temp_threshold = 30
        self.gas_threshold = 400
        self.co2_threshold = 1000

        self.setup_ui()

    def setup_ui(self):
        self.main_frame = ctk.CTkFrame(self.root)
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        self.left_frame = ctk.CTkFrame(self.main_frame)
        self.left_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        self.right_frame = ctk.CTkFrame(self.main_frame, width=320)
        self.right_frame.pack(side="right", fill="y", padx=(10, 0))
        self.right_frame.pack_propagate(False)

        self.setup_graphs()
        self.setup_controls()

    def setup_graphs(self):
        self.fig = Figure(figsize=(9, 6.5), dpi=100, facecolor='#2b2b2b')

        self.ax1 = self.fig.add_subplot(311)
        self.ax2 = self.fig.add_subplot(312)
        self.ax3 = self.fig.add_subplot(313)

        for ax, title, ylabel, color in [
            (self.ax1, "Temperatura", "°C", "#ff6b6b"),
            (self.ax2, "Gas (MQ)", "valore analogico", "#4ecdc4"),
            (self.ax3, "CO₂", "ppm", "#45b7d1"),
        ]:
            ax.set_facecolor('#1e1e1e')
            ax.set_title(title, color='white', fontsize=11)
            ax.set_ylabel(ylabel, color='white', fontsize=9)
            ax.tick_params(colors='white', labelsize=8)
            ax.grid(True, alpha=0.2, color='gray')
            ax.xaxis.set_visible(False)

        self.fig.subplots_adjust(hspace=0.5)

        self.canvas = FigureCanvasTkAgg(self.fig, self.left_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)

        self.line_temp, = self.ax1.plot([], [], color="#ff6b6b", linewidth=2, label="Temperatura")
        self.line_gas, = self.ax2.plot([], [], color="#4ecdc4", linewidth=2, label="Gas")
        self.line_co2, = self.ax3.plot([], [], color="#45b7d1", linewidth=2, label="CO₂")

        self.thresh_line_temp = self.ax1.axhline(y=self.temp_threshold, color='red', linestyle='--', linewidth=1.5, alpha=0.7)
        self.thresh_line_gas = self.ax2.axhline(y=self.gas_threshold, color='red', linestyle='--', linewidth=1.5, alpha=0.7)
        self.thresh_line_co2 = self.ax3.axhline(y=self.co2_threshold, color='red', linestyle='--', linewidth=1.5, alpha=0.7)

    def setup_controls(self):
        # Connessione
        conn_frame = ctk.CTkFrame(self.right_frame)
        conn_frame.pack(fill="x", padx=10, pady=10)

        ctk.CTkLabel(conn_frame, text="Porta COM:", font=("Arial", 12)).pack(pady=2)
        self.port_combo = ctk.CTkComboBox(conn_frame, values=[], state="readonly", width=250)
        self.port_combo.pack(pady=2)
        self.refresh_btn = ctk.CTkButton(conn_frame, text="Aggiorna", command=self.update_ports, height=28)
        self.refresh_btn.pack(pady=2)
        self.connect_btn = ctk.CTkButton(conn_frame, text="Connetti", command=self.toggle_connection, height=35)
        self.connect_btn.pack(pady=5, fill="x")

        self.status_label = ctk.CTkLabel(conn_frame, text="Disconnesso", font=("Arial", 13, "bold"), text_color="red")
        self.status_label.pack(pady=2)

        # Valori attuali
        values_frame = ctk.CTkFrame(self.right_frame)
        values_frame.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(values_frame, text="Valori attuali:", font=("Arial", 14, "bold")).pack(pady=5)

        self.temp_value_label = ctk.CTkLabel(values_frame, text="🌡 Temperatura: -- °C", font=("Arial", 13))
        self.temp_value_label.pack(anchor="w", padx=10)
        self.temp_progress = ctk.CTkProgressBar(values_frame, width=250, height=12)
        self.temp_progress.pack(pady=2, padx=10)
        self.temp_progress.set(0)

        self.gas_value_label = ctk.CTkLabel(values_frame, text="Gas: --", font=("Arial", 13))
        self.gas_value_label.pack(anchor="w", padx=10, pady=(5, 0))
        self.gas_progress = ctk.CTkProgressBar(values_frame, width=250, height=12, fg_color="#2d2d2d")
        self.gas_progress.pack(pady=2, padx=10)
        self.gas_progress.set(0)

        self.co2_value_label = ctk.CTkLabel(values_frame, text="CO₂: -- ppm", font=("Arial", 13))
        self.co2_value_label.pack(anchor="w", padx=10, pady=(5, 0))
        self.co2_progress = ctk.CTkProgressBar(values_frame, width=250, height=12, fg_color="#2d2d2d")
        self.co2_progress.pack(pady=2, padx=10)
        self.co2_progress.set(0)

        # Allarmi
        alarm_frame = ctk.CTkFrame(self.right_frame)
        alarm_frame.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(alarm_frame, text="Stato allarmi:", font=("Arial", 14, "bold")).pack(pady=5)

        self.alarm_temp = ctk.CTkLabel(alarm_frame, text="Temperatura OK", font=("Arial", 12), text_color="green")
        self.alarm_temp.pack(anchor="w", padx=10)

        self.alarm_gas = ctk.CTkLabel(alarm_frame, text="Gas OK", font=("Arial", 12), text_color="green")
        self.alarm_gas.pack(anchor="w", padx=10)

        self.alarm_co2 = ctk.CTkLabel(alarm_frame, text="CO₂ OK", font=("Arial", 12), text_color="green")
        self.alarm_co2.pack(anchor="w", padx=10)

        # Log
        log_frame = ctk.CTkFrame(self.right_frame)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)

        ctk.CTkLabel(log_frame, text="Log eventi:", font=("Arial", 12, "bold")).pack(pady=5)

        self.log_text = tk.Text(log_frame, height=8, bg='#1e1e1e', fg='white',
                                font=("Consolas", 9), wrap=tk.WORD)
        self.log_text.pack(fill="both", expand=True, padx=5, pady=5)
        scrollbar = ttk.Scrollbar(self.log_text, command=self.log_text.yview)
        scrollbar.pack(side="right", fill="y")
        self.log_text.config(yscrollcommand=scrollbar.set)

        # Pulsante esci
        self.exit_btn = ctk.CTkButton(
            self.right_frame, text="Esci", command=self.on_closing,
            fg_color="red", hover_color="darkred", height=35
        )
        self.exit_btn.pack(padx=10, pady=10, fill="x")

        self.update_ports()

    def add_log(self, message, is_error=False):
        timestamp = datetime.now().strftime("%H:%M:%S")
        tag = "error" if is_error else "info"
        formatted = f"[{timestamp}] {message}\n"
        self.log_text.insert(tk.END, formatted)
        self.log_text.see(tk.END)
        if is_error:
            start = self.log_text.index("end-2l")
            end = self.log_text.index("end-1c")
            self.log_text.tag_add("error", start, end)
            self.log_text.tag_config("error", foreground="red")

    def update_ports(self):
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_combo.configure(values=ports)
        if ports:
            self.port_combo.set(ports[0])

    def toggle_connection(self):
        if self.running:
            self.disconnect()
        else:
            self.connect()

    def connect(self):
        port = self.port_combo.get()
        if not port:
            messagebox.showerror("Errore", "Seleziona una porta COM")
            return
        try:
            self.ser = serial.Serial(port, 9600, timeout=1)
            self.running = True
            self.connect_btn.configure(text="Disconnetti")
            self.status_label.configure(text=f"Connesso a {port}", text_color="green")
            self.add_log(f"Connesso a {port}")
            threading.Thread(target=self.read_serial, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Errore", f"Impossibile connettersi: {e}")

    def disconnect(self):
        self.running = False
        if self.ser:
            self.ser.close()
            self.ser = None
        self.connect_btn.configure(text="Connetti")
        self.status_label.configure(text="Disconnesso", text_color="red")

    def read_serial(self):
        while self.running:
            try:
                if self.ser and self.ser.in_waiting:
                    line = self.ser.readline().decode("utf-8").strip()
                    if line:
                        parts = line.split(",")
                        if len(parts) == 3:
                            temp = float(parts[0])
                            gas = float(parts[1])
                            co2 = float(parts[2])

                            self.current_temp = temp
                            self.current_gas = gas
                            self.current_co2 = co2

                            self.temp_data.append(temp)
                            self.gas_data.append(gas)
                            self.co2_data.append(co2)
                            self.timestamps.append(len(self.timestamps))

                            self.root.after(0, self.update_ui)
            except Exception as e:
                self.add_log(f"Errore lettura: {e}", is_error=True)
                self.running = False
                self.root.after(0, lambda: self.status_label.configure(text="Disconnesso", text_color="red"))
                self.root.after(0, lambda: self.connect_btn.configure(text="Connetti"))
            time.sleep(0.05)

    def update_ui(self):
        t, g, c = self.current_temp, self.current_gas, self.current_co2

        self.temp_value_label.configure(text=f"Temperatura: {t:.1f} °C")
        self.gas_value_label.configure(text=f"Gas: {g:.0f}")
        self.co2_value_label.configure(text=f"CO₂: {c:.0f} ppm")

        self.temp_progress.set(min(t / 60, 1.0))
        self.gas_progress.set(min(g / 1023, 1.0))
        self.co2_progress.set(min(c / 2500, 1.0))

        # Allarmi
        if t > self.temp_threshold:
            self.alarm_temp.configure(text="TEMPERATURA ALTA!", text_color="red")
            self.add_log(f"ALLARME: Temperatura {t:.1f}°C (soglia {self.temp_threshold}°C)", is_error=True)
        else:
            self.alarm_temp.configure(text="✅ Temperatura OK", text_color="green")

        if g > self.gas_threshold:
            self.alarm_gas.configure(text="GAS RILEVATO!", text_color="red")
            self.add_log(f"ALLARME: Gas {g:.0f} (soglia {self.gas_threshold})", is_error=True)
        else:
            self.alarm_gas.configure(text="✅ Gas OK", text_color="green")

        if c > self.co2_threshold:
            self.alarm_co2.configure(text="CO₂ ALTA!", text_color="red")
            self.add_log(f"ALLARME: CO₂ {c:.0f} ppm (soglia {self.co2_threshold} ppm)", is_error=True)
        else:
            self.alarm_co2.configure(text="CO₂ OK", text_color="green")

        # Grafici
        x = list(range(len(self.temp_data)))

        self.ax1.clear()
        self.ax1.set_facecolor('#1e1e1e')
        self.ax1.plot(x, list(self.temp_data), color="#ff6b6b", linewidth=2, label="Temperatura")
        self.ax1.axhline(y=self.temp_threshold, color='red', linestyle='--', linewidth=1.5, alpha=0.7, label=f"Soglia {self.temp_threshold}°C")
        self.ax1.set_title("Temperatura", color='white', fontsize=11)
        self.ax1.set_ylabel("°C", color='white', fontsize=9)
        self.ax1.tick_params(colors='white', labelsize=8)
        self.ax1.grid(True, alpha=0.2, color='gray')
        self.ax1.legend(loc='upper right', facecolor='#2b2b2b', labelcolor='white', fontsize=8)
        self.ax1.xaxis.set_visible(False)

        self.ax2.clear()
        self.ax2.set_facecolor('#1e1e1e')
        self.ax2.plot(x, list(self.gas_data), color="#4ecdc4", linewidth=2, label="Gas")
        self.ax2.axhline(y=self.gas_threshold, color='red', linestyle='--', linewidth=1.5, alpha=0.7, label=f"Soglia {self.gas_threshold}")
        self.ax2.set_title("Gas (MQ)", color='white', fontsize=11)
        self.ax2.set_ylabel("valore analogico", color='white', fontsize=9)
        self.ax2.tick_params(colors='white', labelsize=8)
        self.ax2.grid(True, alpha=0.2, color='gray')
        self.ax2.legend(loc='upper right', facecolor='#2b2b2b', labelcolor='white', fontsize=8)
        self.ax2.xaxis.set_visible(False)

        self.ax3.clear()
        self.ax3.set_facecolor('#1e1e1e')
        self.ax3.plot(x, list(self.co2_data), color="#45b7d1", linewidth=2, label="CO₂")
        self.ax3.axhline(y=self.co2_threshold, color='red', linestyle='--', linewidth=1.5, alpha=0.7, label=f"Soglia {self.co2_threshold} ppm")
        self.ax3.set_title("CO₂", color='white', fontsize=11)
        self.ax3.set_ylabel("ppm", color='white', fontsize=9)
        self.ax3.set_xlabel("campioni", color='white', fontsize=9)
        self.ax3.tick_params(colors='white', labelsize=8)
        self.ax3.grid(True, alpha=0.2, color='gray')
        self.ax3.legend(loc='upper right', facecolor='#2b2b2b', labelcolor='white', fontsize=8)

        self.canvas.draw()

    def on_closing(self):
        self.running = False
        if self.ser and self.ser.is_open:
            self.ser.close()
        self.root.destroy()

if __name__ == "__main__":
    root = ctk.CTk()
    app = SensorMonitorApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()
